python operMain.py
python traGraphique.py