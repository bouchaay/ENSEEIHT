package ShemaTableElements;

public enum ColumnDataTypeA {
    INTEGER,
    FLOAT,
    STRING;
}
