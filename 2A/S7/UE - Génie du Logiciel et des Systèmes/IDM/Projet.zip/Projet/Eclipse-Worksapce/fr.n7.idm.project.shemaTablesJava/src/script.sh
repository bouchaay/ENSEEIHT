python Ressource/operMain.py
python traGraphique.py