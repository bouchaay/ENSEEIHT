package getXMI;

public class MainF {
	
	public static void main(String[] args) {
		TablesF Tab = new TablesF();
		Tab.tablesGUI();
	}
}
