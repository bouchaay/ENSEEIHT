/**
 */
package shematables;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see shematables.ShematablesPackage#getOutput()
 * @model
 * @generated
 */
public interface Output extends Column {
} // Output
