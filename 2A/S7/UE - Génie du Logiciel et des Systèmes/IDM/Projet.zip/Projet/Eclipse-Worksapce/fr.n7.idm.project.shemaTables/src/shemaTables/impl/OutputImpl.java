/**
 */
package shematables.impl;

import org.eclipse.emf.ecore.EClass;

import shematables.Output;
import shematables.ShematablesPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class OutputImpl extends ColumnImpl implements Output {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutputImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ShematablesPackage.Literals.OUTPUT;
	}

} //OutputImpl
