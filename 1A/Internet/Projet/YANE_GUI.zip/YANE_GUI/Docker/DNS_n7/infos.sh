firefox https://www.vultr.com/docs/setup-your-own-dns-server-on-debian-ubuntu
